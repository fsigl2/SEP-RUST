// Uncomment the following line to ignore dead code warnings:
// #![allow(dead_code)]

// If you're stuck, check out the official Rust tutorial book and/or Rust by Example:
// https://rust-book.cs.brown.edu/ch04-00-understanding-ownership.html
// https://doc.rust-lang.org/rust-by-example/

/// Ex.2a
// Fix the compiler error in this function
// Then fix the error in ex1a_test below
fn vec_77(vec: Vec<i32>) -> Vec<i32> {
    vec.push(77);
    vec
}

/// Ex.2b
// Fix the error only by reordering the lines
// Don't add, remove or change any lines
fn mut_borrow() -> Vec<i32> {
    let mut x = Vec::new();
    let y = &mut x;
    let z = &mut x;
    y.push(42);
    z.push(7);

    x
}

/// Ex.2c
// What needs to be changed in these two functions so that the code in the main function works?
// Don't change any lines in the main function!
fn get_char(s: String) -> char {
    s.chars().last().unwrap()
}

fn string_uppercase(mut s: &String) {
    s = s.to_uppercase();

    println!("{s}");
}

/// Ex.2d
// What needs to be changed so the code in the main function works?
// There are multiple ways!
// For this you can change code in the main function as well
#[derive(Debug)]
struct Person {
    age: u8,
}

fn main() {
    // Ex.2c
    let s = "Rust is the best!".to_string();
    get_char(s);
    string_uppercase(&s);

    // Ex.2d
    let alice = Person { age: 42 };
    let bob = alice;
    println!("Alice: {:?}\nBob: {:?}", alice, bob);
}

// You can add more tests below here, which you can then execute with 'cargo test'
#[cfg(test)]
mod tests {
    use super::*;

    // Fix the errors here
    #[test]
    fn ex2a_test() {
        let vec0 = vec![11, 33, 55];
        let vec1 = vec_77(vec0);

        assert_eq!(vec0, vec![11, 33, 55]);
        assert_eq!(vec1, vec![11, 33, 55, 77]);
    }

    #[test]
    fn ex2b_test() {
        let res = mut_borrow();
        assert_eq!(res, vec![42, 67]);
    }
}
